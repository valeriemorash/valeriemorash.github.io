function[out] = normalizeImage(img)

mean = mean2(img);
std  = std2(img);
out  = (img(:,:)-mean)/std;
return