function[out]=ridge(img,sigma)

    Lx  = gfilter(img,sigma,[0 1]);
    Lxx = gfilter(img,sigma,[0 2]);
    Ly  = gfilter(img,sigma,[1 0]);
    Lxy = gfilter(img,sigma,[1 1]);
    Lyy = gfilter(img,sigma,[2 0]);

    out =(-2*(Lx.*Lxy.*Ly)+(Lxx.*Ly.*Ly)+(Lx.*Lx.*Lyy))./((Lx.*Lx)+(Ly.*Ly));
return