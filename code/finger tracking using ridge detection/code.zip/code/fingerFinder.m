close all force
clear all

disp(['This code makes use of the gaussdiff functions by Almar Klein, available at: '...
    'http://www.mathworks.com/matlabcentral/fileexchange/19696-gaussdiff/content/gaussiankernel.m']);
disp('gaussiankernel.m');
disp('gfilter.m');

homewd = pwd;
addpath(homewd);

frames = 1:110;
fingerCoordinates = [frames' frames'*NaN frames'*NaN];
%first column is the frame number
%second column is the index finger position x
%third column is the index finger position y

%%BACKGROUND IMAGE FOR SUBTRACTION
cd('images');
background = imread('background.bmp');
cd(homewd);
backgroundHSV = rgb2hsv(background);

%%MAXIMUM DISTANCE A FINGER CAN TRAVEL (IN PIXELS) BETWEEN FRAMES
maxTravelDistance = 80;

%%GAUSSIAN KERNEL
sigma = 16;

for i = 1:length(frames)
    
    %%LOAD VIDEO FRAME IMAGE
    cd('images');
    im = imread(['frame' num2str(frames(i)) '.bmp']);
    cd(homewd);
    imHSV = rgb2hsv(im);
    imdif = imHSV(:,:,3) - backgroundHSV(:,:,3);
    
    ridges = ridge(imdif,sigma);
    normRidges   = normalizeImage(ridges);
    
    %%For each Cluster, find it's distance from the
    %%last value, or if there is no last value, how
    %%close it is to the middle
    
    currentMin = 10000; %Upper bound - any distance between a location and
                        %a predicted location should be less than this
                        
    %%PREDICTED FINGER LOCATION IN THIS VIDEO FRAME
    switch i
        case 1
            predictedX = 1000; %Center
            predictedY = 500; %Center
        case 2
            predictedX = fingerCoordinates(i-1,2);
            predictedY = fingerCoordinates(i-1,3);
        otherwise
            predictedX = 2*fingerCoordinates(i-1,2) - fingerCoordinates(i-2,2);
            predictedY = 2*fingerCoordinates(i-1,3) - fingerCoordinates(i-2,3);
    end
    
    %%IF A NEW ESTIMATE CANNOT BE FOUND USE THE PREDICTIONS
    fingerCoordinates(i,2) = predictedX;
    fingerCoordinates(i,3) = predictedY;
    
    for threshold = [.22 0.18 0.12]
        for erode = [22 16 8]
            
            %%THRESHOLD
            threshRidges = im2bw(normRidges/max(normRidges(:)),threshold);
            
            %%ERODE
            se1 = strel('disk',erode);
            threshRidges = imerode(threshRidges,se1);
            
            %%DILATE
            se2 = strel('disk',erode);
            threshRidges = imdilate(threshRidges,se2);
            
            %%CLUSTERS
            CC = bwconncomp(threshRidges);
            
            %%FIND THE CLUSTER THAT GOES WITH THE INDEX FINGER
            currentGroup = 1;
            distanceFromLast = [];
            for ix = 1:CC.NumObjects
                
                %%PIXELS IN CURRENT CLUSTER
                [I,J] = ind2sub(CC.ImageSize, CC.PixelIdxList{ix});
                
                distanceFromLast(ix) =  minClusterDistance(...
                    predictedX,...
                    predictedY,...
                    J,I);
                
                if distanceFromLast(ix) < currentMin
                    currentGroup = ix;
                    currentMin = distanceFromLast(ix);
                    currentThreshold = threshRidges; %FOR PLOTTING
                    chosenThreshold = threshold;
                    chosenErode = erode;
                    
                    [I,J] = ind2sub(CC.ImageSize, CC.PixelIdxList{currentGroup});
                    
                    indexMin = find(I==min(I));
                    indexMin = indexMin(1);
                    indexMax = find(I==max(I));
                    indexMax = indexMax(1);
                    
                   
                    %%THIS IS A HUGE CLUSTER, SO CHECK IF IT IS TOO WIDE OR
                    %%TOO TALL AND NARROW.
                    if (max(I)-min(I)) / (max(J) - min(J)) >= 5
                        J = J((I<=quantile(I,.25))); %%TOO TALL AND SKINNY
                        I = I(I<=quantile(I,.25));
                    else if (max(J) - min(J)) > 45 %%TOO WIDE
                            J = J((J<=quantile(J,.25)));
                            I = I(J<=quantile(J,.25));
                        end
                    end
                    
                    fingerCoordinates(i,2) = mean(J);
                    fingerCoordinates(i,3) = mean(I);
                end
            end
            
        end
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%CREATE ANIMATED GIFS OF RESULTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %%PLOT THRESHOLDED WITH LOCATION
%     close all
%     imagesc(currentThreshold);
%     colormap(gray);
%     hold on
%     plot(fingerCoordinates(i,2),fingerCoordinates(i,3),'r*');
%     set(gca,'XTick',[]);
%     set(gca,'YTick',[]);
%     axis equal
%     axis tight
%     pause(0.1);
%     
%     drawnow
%     frame = getframe(gca);
%     frameIM = frame2im(frame);
%     [imind,cm] = rgb2ind(frameIM,256);
%     if i == 1;
%         imwrite(imind,cm,'thresholded.gif','gif', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,'thresholded.gif','gif','WriteMode','append');
%     end
%     
%     %%PLOT RIDGES WITH LOCATION
%     close all
%     imagesc(normRidges);
%     colormap(gray);
%     hold on
%     plot(fingerCoordinates(i,2),fingerCoordinates(i,3),'r*');
%     set(gca,'XTick',[]);
%     set(gca,'YTick',[]);
%     axis equal
%     axis tight
%     pause(0.1);
%     
%     drawnow
%     frame = getframe(gca);
%     frameIM = frame2im(frame);
%     [imind,cm] = rgb2ind(frameIM,256);
%     if i == 1;
%         imwrite(imind,cm,'ridges.gif','gif', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,'ridges.gif','gif','WriteMode','append');
%     end
%     
%     %%PLOT IMAGE WITH LOCATION
%     close all
%     imagesc(im);
%     colormap(gray);
%     hold on
%     plot(fingerCoordinates(i,2),fingerCoordinates(i,3),'r*');
%     set(gca,'XTick',[]);
%     set(gca,'YTick',[]);
%     axis equal
%     axis tight
%     pause(0.1);
%     
%     drawnow
%     frame = getframe(gca);
%     frameIM = frame2im(frame);
%     [imind,cm] = rgb2ind(frameIM,256);
%     if i == 1;
%         imwrite(imind,cm,'image.gif','gif', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,'image.gif','gif','WriteMode','append');
%     end
    
end

fingerCoordinates


%%% NOTE: Finger locations need to be correct for camera perspective before
%%% they are analyzed. This is easily accomplished using the following:
%%% tform = maketform('projective',input,output);
%%% Where input is selected points on the image (e.g., we use the corners
%%% of the tactile map) and output is the desired points for these to be 
%%% mapped to (e.g., for the map corners we used:
%%%                 output = [1 1;...
%%%                           1000 1;...
%%%                           1000 1000;...
%%%                           1 1000];
%%% The image can be transformed as:
%%% newImage = imtransform(image, tform,'XYScale',1);
%%% Then to transform coordinates (X,Y):
%%% [XT, YT] = tformfwd(tform, X, Y);