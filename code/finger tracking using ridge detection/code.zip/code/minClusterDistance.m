function minDistance = minClusterDistance(x,y,clusterXs,clusterYs)


distances = sqrt((x*ones(size(clusterXs))-clusterXs(:)).^2 + (y*ones(size(clusterYs))-clusterYs(:)).^2);

minDistance = min(distances);